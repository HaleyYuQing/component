# iOS_Category
a simple project for iOS Category
* 这个工程提供了一些iOS开发中用到的类目, 方便开发
* pod 'iOS_Category'
* 这些类目分为Foundation 和 UI 两部分 , 
根据需要 
#import < Foundation_Category.h >
或者
#import < UI_Category.h >
